一、设置远程连接k8s
1、执行脚本
bash jump-k8s.sh
2、切换至普通用户jump
su jump
3、测试
kubectl get roles

二、说明
远程用户jump使用命名空间cmdicncf
