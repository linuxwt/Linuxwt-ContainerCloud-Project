#!/bin/bash

##设置config##
mkdir -p /home/jump/.kube
mv config /home/jump/.kube/
chown -R jump:jump /home/jump/.kube
echo "export KUBECONFIG=/home/jump/.kube/config" >> /home/jump/.bashrc   

##设置kubectl##
mv kubectl /usr/bin
chmod +x /usr/bin/kubectl
