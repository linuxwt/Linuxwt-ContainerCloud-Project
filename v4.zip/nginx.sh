yumdownloader --resolve --destdir=nginxdir nginx \
gd \
jbigkit-libs \
libXpm \
libjpeg-turbo \
libtiff \
libwebp \
nginx-all-modules \
nginx-filesystem \
nginx-mod-http-image-filter \
nginx-mod-http-perl \
nginx-mod-http-xslt-filter \
nginx-mod-mail \
nginx-mod-stream
