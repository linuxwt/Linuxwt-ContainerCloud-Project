#!/bin/bash

chmod +x cfssl*
cp cfssl_linux-amd64 /usr/bin/cfssl
cp cfssljson_linux-amd64 /usr/bin/cfssljson
cp cfssl-certinfo_linux-amd64 /usr/bin/cfssl-certinfo
